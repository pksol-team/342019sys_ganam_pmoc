<?php $__env->startSection("contentheader_title"); ?>
	<a href="<?php echo e(url(config('laraadmin.adminRoute') . '/case_screens')); ?>">ケース画面</a> :
<?php $__env->stopSection(); ?>
<?php $__env->startSection("contentheader_description", $case_screen->$view_col); ?>
<?php $__env->startSection("section", "ケース画面"); ?>
<?php $__env->startSection("section_url", url(config('laraadmin.adminRoute') . '/case_screens')); ?>
<?php $__env->startSection("sub_section", "編集する"); ?>

<?php $__env->startSection("htmlheader_title", "ケース画面編集 : ".$case_screen->$view_col); ?>

<?php $__env->startSection("main-content"); ?>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="box">
	<div class="box-header">
		
	</div>
	<div class="box-body">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<?php echo Form::model($case_screen, ['route' => [config('laraadmin.adminRoute') . '.case_screens.update', $case_screen->id ], 'method'=>'PUT', 'id' => 'case_screen-edit-form']); ?>

					<?php echo LAFormMaker::form($module); ?>
					
					<?php /*
					<?php echo LAFormMaker::input($module, 'customer_name'); ?>
					<?php echo LAFormMaker::input($module, 'record_type'); ?>
					<?php echo LAFormMaker::input($module, 'case_name'); ?>
					<?php echo LAFormMaker::input($module, 'task_name'); ?>
					<?php echo LAFormMaker::input($module, 'grant_total'); ?>
					<?php echo LAFormMaker::input($module, 'target_name'); ?>
					<?php echo LAFormMaker::input($module, 'content_preparation'); ?>
					<?php echo LAFormMaker::input($module, 'project_proposal_day'); ?>
					<?php echo LAFormMaker::input($module, 'expiration_date'); ?>
					<?php echo LAFormMaker::input($module, 'application_amount'); ?>
					<?php echo LAFormMaker::input($module, 'scheduled_date_1'); ?>
					<?php echo LAFormMaker::input($module, 'scheduled_date_2'); ?>
					<?php echo LAFormMaker::input($module, 'scheduled_date_3'); ?>
					<?php echo LAFormMaker::input($module, 'stop'); ?>
					<?php echo LAFormMaker::input($module, 'reserved'); ?>
					<?php echo LAFormMaker::input($module, 'case_close_check'); ?>
					<?php echo LAFormMaker::input($module, 'remarks'); ?>
					<?php echo LAFormMaker::input($module, 'final_update_date'); ?>
					*/ ?>
                    <br>
					<div class="form-group">
						<?php echo Form::submit( '更新', ['class'=>'btn btn-success']); ?> <button class="btn btn-default pull-right"><a href="<?php echo e(url(config('laraadmin.adminRoute') . '/case_screens')); ?>">キャンセル</a></button>
					</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
	$("#case_screen-edit-form").validate({
		
	});
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("la.layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>