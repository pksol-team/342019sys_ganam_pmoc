<?php if(!isset($no_padding)): ?>
<footer class="main-footer">
	<div class="pull-right hidden-xs">
        によって開発された <a href="http://www.pksol.com">PK SOL</a>
    </div>
    <strong>著作権 &copy; 2019
</footer>
<?php endif; ?>