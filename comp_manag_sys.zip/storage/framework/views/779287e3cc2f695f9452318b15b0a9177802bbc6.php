<?php $__env->startSection('htmlheader_title'); ?>
	Employee View
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
<div id="page-content" class="profile2">
	<!-- <div class="bg-success clearfix">
		<div class="col-md-4">
			<div class="row">
				<div class="col-md-3">
					<img class="profile-image" src="<?php echo e(Gravatar::fallback(asset('/img/avatar5.png'))->get(Auth::user()->email, ['size'=>400])); ?>" alt="">
				</div>
				<div class="col-md-9">
					<h4 class="name"><?php echo e($employee->$view_col); ?></h4>
					<div class="row stats">
						<div class="col-md-6 stat"><div class="label2" data-toggle="tooltip" data-placement="top" title="Designation"><?php echo e($employee->designation); ?></div></div>
						<div class="col-md-6 stat"><i class="fa fa-map-marker"></i> <?php echo e(isset($employee->city) ? $employee->city : "NA"); ?></div>
					</div>
					<p class="desc"><?php echo e(substr($employee->about, 0, 33)); ?><?php if(strlen($employee->about) > 33): ?>...<?php endif; ?></p>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="dats1"><i class="fa fa-envelope-o"></i> <?php echo e($employee->email); ?></div>
			<div class="dats1"><i class="fa fa-phone"></i> <?php echo e($employee->mobile); ?></div>
			<div class="dats1"><i class="fa fa-clock-o"></i> Joined on <?php echo e(date("M d, Y", strtotime($employee->date_hire))); ?></div>
		</div>
		<div class="col-md-4">
			<div class="teamview">
				<a class="face" data-toggle="tooltip" data-placement="top" title="John Doe"><img src="<?php echo e(asset('la-assets/img/user1-128x128.jpg')); ?>" alt=""><i class="status-online"></i></a>
				<a class="face" data-toggle="tooltip" data-placement="top" title="John Doe"><img src="<?php echo e(asset('la-assets/img/user2-160x160.jpg')); ?>" alt=""></a>
				<a class="face" data-toggle="tooltip" data-placement="top" title="John Doe"><img src="<?php echo e(asset('la-assets/img/user3-128x128.jpg')); ?>" alt=""></a>
				<a class="face" data-toggle="tooltip" data-placement="top" title="John Doe"><img src="<?php echo e(asset('la-assets/img/user4-128x128.jpg')); ?>" alt=""><i class="status-online"></i></a>
				<a class="face" data-toggle="tooltip" data-placement="top" title="John Doe"><img src="<?php echo e(asset('la-assets/img/user5-128x128.jpg')); ?>" alt=""></a>
				<a class="face" data-toggle="tooltip" data-placement="top" title="John Doe"><img src="<?php echo e(asset('la-assets/img/user6-128x128.jpg')); ?>" alt=""></a>
				<a class="face" data-toggle="tooltip" data-placement="top" title="John Doe"><img src="<?php echo e(asset('la-assets/img/user7-128x128.jpg')); ?>" alt=""></a>
				<a class="face" data-toggle="tooltip" data-placement="top" title="John Doe"><img src="<?php echo e(asset('la-assets/img/user8-128x128.jpg')); ?>" alt=""></a>
				<a class="face" data-toggle="tooltip" data-placement="top" title="John Doe"><img src="<?php echo e(asset('la-assets/img/user5-128x128.jpg')); ?>" alt=""></a>
				<a class="face" data-toggle="tooltip" data-placement="top" title="John Doe"><img src="<?php echo e(asset('la-assets/img/user6-128x128.jpg')); ?>" alt=""><i class="status-online"></i></a>
				<a class="face" data-toggle="tooltip" data-placement="top" title="John Doe"><img src="<?php echo e(asset('la-assets/img/user7-128x128.jpg')); ?>" alt=""></a>
			</div>
			
		</div>
		<div class="col-md-1 actions">
			<?php if(LAFormMaker::la_access("Employees", "edit")) { ?>
				<a href="<?php echo e(url(config('laraadmin.adminRoute') . '/employees/'.$employee->id.'/edit')); ?>" class="btn btn-xs btn-edit btn-default"><i class="fa fa-pencil"></i></a><br>
			<?php } ?>
			
			<?php if(LAFormMaker::la_access("Employees", "delete")) { ?>
				<?php echo e(Form::open(['route' => [config('laraadmin.adminRoute') . '.employees.destroy', $employee->id], 'method' => 'delete', 'style'=>'display:inline'])); ?>

					<button class="btn btn-default btn-delete btn-xs" type="submit"><i class="fa fa-times"></i></button>
				<?php echo e(Form::close()); ?>

			<?php } ?>
		</div>
	</div> -->

	<ul data-toggle="ajax-tab" class="nav nav-tabs profile" role="tablist">
		<li class=""><a href="<?php echo e(url(config('laraadmin.adminRoute') . '/employees')); ?>" data-toggle="tooltip" data-placement="right" title="Back to Employees"><i class="fa fa-chevron-left"></i></a></li>
		<li class="active"><a role="tab" data-toggle="tab" class="active" href="#tab-info" data-target="#tab-info"><i class="fa fa-bars"></i> General Info</a></li>
		<!-- <li class=""><a role="tab" data-toggle="tab" href="#tab-timeline" data-target="#tab-timeline"><i class="fa fa-clock-o"></i> Timeline</a></li> -->
		<?php if($employee->id == Auth::user()->id || Entrust::hasRole("SUPER_ADMIN")): ?>
			<li class=""><a role="tab" data-toggle="tab" href="#tab-account-settings" data-target="#tab-account-settings"><i class="fa fa-key"></i> Account settings</a></li>
		<?php endif; ?>
	</ul>

	<div class="tab-content">
		<div role="tabpanel" class="tab-pane active fade in" id="tab-info">
			<div class="tab-content">
				<div class="panel infolist">
					<div class="panel-default panel-heading">
						<h4>General Info</h4>
					</div>
					<div class="panel-body">
						<?php echo LAFormMaker::display($module, 'name'); ?>
						<!-- <?php echo LAFormMaker::display($module, 'designation'); ?> -->
						<?php echo LAFormMaker::display($module, 'gender'); ?>
						<?php echo LAFormMaker::display($module, 'mobile'); ?>
						<?php echo LAFormMaker::display($module, 'mobile2'); ?>
						<?php echo LAFormMaker::display($module, 'email'); ?>
						<!-- <?php echo LAFormMaker::display($module, 'dept'); ?> -->
						<?php echo LAFormMaker::display($module, 'city'); ?>
						<?php echo LAFormMaker::display($module, 'address'); ?>
						<?php echo LAFormMaker::display($module, 'about'); ?>
						<?php echo LAFormMaker::display($module, 'date_birth'); ?>
						<!-- <?php echo LAFormMaker::display($module, 'date_hire'); ?>
						<?php echo LAFormMaker::display($module, 'date_left'); ?>
						<?php echo LAFormMaker::display($module, 'salary_cur'); ?> -->
					</div>
				</div>
			</div>
		</div>
		<div role="tabpanel" class="tab-pane fade in p20 bg-white" id="tab-timeline">
			<ul class="timeline timeline-inverse">
				<!-- timeline time label -->
				<li class="time-label">
					<span class="bg-red">
						10 Feb. 2014
					</span>
				</li>
				<!-- /.timeline-label -->
				<!-- timeline item -->
				<li>
				<i class="fa fa-envelope bg-blue"></i>

				<div class="timeline-item">
					<span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

					<h3 class="timeline-header"><a href="#">Support Team</a> sent you an email</h3>

					<div class="timeline-body">
					Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,
					weebly ning heekya handango imeem plugg dopplr jibjab, movity
					jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle
					quora plaxo ideeli hulu weebly balihoo...
					</div>
					<div class="timeline-footer">
					<a class="btn btn-primary btn-xs">Read more</a>
					<a class="btn btn-danger btn-xs">Delete</a>
					</div>
				</div>
				</li>
				<!-- END timeline item -->
				<!-- timeline item -->
				<li>
				<i class="fa fa-user bg-aqua"></i>

				<div class="timeline-item">
					<span class="time"><i class="fa fa-clock-o"></i> 5 mins ago</span>

					<h3 class="timeline-header no-border"><a href="#">Sarah Young</a> accepted your friend request
					</h3>
				</div>
				</li>
				<!-- END timeline item -->
				<!-- timeline item -->
				<li>
				<i class="fa fa-comments bg-yellow"></i>

				<div class="timeline-item">
					<span class="time"><i class="fa fa-clock-o"></i> 27 mins ago</span>

					<h3 class="timeline-header"><a href="#">Jay White</a> commented on your post</h3>

					<div class="timeline-body">
					Take me to your leader!
					Switzerland is small and neutral!
					We are more like Germany, ambitious and misunderstood!
					</div>
					<div class="timeline-footer">
					<a class="btn btn-warning btn-flat btn-xs">View comment</a>
					</div>
				</div>
				</li>
				<!-- END timeline item -->
				<!-- timeline time label -->
				<li class="time-label">
					<span class="bg-green">
						3 Jan. 2014
					</span>
				</li>
				<!-- /.timeline-label -->
				<!-- timeline item -->
				<li>
				<i class="fa fa-camera bg-purple"></i>

				<div class="timeline-item">
					<span class="time"><i class="fa fa-clock-o"></i> 2 days ago</span>

					<h3 class="timeline-header"><a href="#">Mina Lee</a> uploaded new photos</h3>

					<div class="timeline-body">
					<img src="http://placehold.it/150x100" alt="..." class="margin">
					<img src="http://placehold.it/150x100" alt="..." class="margin">
					<img src="http://placehold.it/150x100" alt="..." class="margin">
					<img src="http://placehold.it/150x100" alt="..." class="margin">
					</div>
				</div>
				</li>
				<!-- END timeline item -->
				<li>
				<i class="fa fa-clock-o bg-gray"></i>
				</li>
			</ul>
			<!--<div class="text-center p30"><i class="fa fa-list-alt" style="font-size: 100px;"></i> <br> No posts to show</div>-->
		</div>
		
		<?php if($employee->id == Auth::user()->id || Entrust::hasRole("SUPER_ADMIN")): ?>
		<div role="tabpanel" class="tab-pane fade" id="tab-account-settings">
			<div class="tab-content">
				<form action="<?php echo e(url(config('laraadmin.adminRoute') . '/change_password/'.$employee->id)); ?>" id="password-reset-form" class="general-form dashed-row white" method="post" accept-charset="utf-8">
					<?php echo e(csrf_field()); ?>

					<div class="panel">
						<div class="panel-default panel-heading">
							<h4>Account settings</h4>
						</div>
						<div class="panel-body">
							<?php if(count($errors) > 0): ?>
								<div class="alert alert-danger">
									<ul>
										<?php foreach($errors->all() as $error): ?>
											<li><?php echo e($error); ?></li>
										<?php endforeach; ?>
									</ul>
								</div>
							<?php endif; ?>
							<?php if(Session::has('success_message')): ?>
								<p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('success_message')); ?></p>
							<?php endif; ?>
							<div class="form-group">
								<label for="password" class=" col-md-2">Password</label>
								<div class=" col-md-10">
									<input type="password" name="password" value="" id="password" class="form-control" placeholder="Password" autocomplete="off" required="required" data-rule-minlength="6" data-msg-minlength="Please enter at least 6 characters.">
								</div>
							</div>
							<div class="form-group">
								<label for="password_confirmation" class=" col-md-2">Retype password</label>
								<div class=" col-md-10">
									<input type="password" name="password_confirmation" value="" id="password_confirmation" class="form-control" placeholder="Retype password" autocomplete="off" required="required" data-rule-equalto="#password" data-msg-equalto="Please enter the same value again.">
								</div>
							</div>
						</div>
						<div class="panel-footer">
							<button type="submit" class="btn btn-primary"><span class="fa fa-check-circle"></span> Change Password</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		<?php endif; ?>
	</div>
	</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
	<?php if($employee->id == Auth::user()->id || Entrust::hasRole("SUPER_ADMIN")): ?>
	$('#password-reset-form').validate({
		
	});
	<?php endif; ?>
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('la.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>