<?php $__env->startSection('htmlheader_title'); ?>
    ログイン
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<body class="hold-transition login-page">
    <div class="login-box">
        <div style="text-align: center; margin-bottom:50px;">
            <img width="80%" src="<?php echo e(asset('la-assets/img/logo.png')); ?>" alt="Rose Group" />
        </div>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>おっと!</strong> 入力に問題がありました.<br><br>
            <ul>
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="login-box-body">
    <p class="login-box-msg">サインインしてセッションを開始してください</p>
    <form action="<?php echo e(url('/login')); ?>" method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="form-group has-feedback">
            <input type="email" class="form-control" placeholder="Eメール" name="email"/>
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        </div>
        <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="パスワード" name="password"/>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        </div>
        <div class="row">
            <div class="col-xs-8">
                <div class="checkbox icheck">
                    <label>
                        <input type="checkbox" name="remember"> 私を覚えてますか
                    </label>
                </div>
            </div><!-- /.col -->
            <div class="col-xs-4">
                <button type="submit" class="btn btn-primary btn-block btn-flat">サインイン</button>
            </div><!-- /.col -->
        </div>
    </form>

    <?php echo $__env->make('auth.partials.social_login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- <a href="<?php echo e(url('/password/reset')); ?>">I forgot my password</a><br><br> -->
    <!-- <a href="<?php echo e(url('register')); ?>">Don't Have Account? Register</a><br> -->
    <!--<a href="<?php echo e(url('/register')); ?>" class="text-center">Register a new membership</a>-->

</div><!-- /.login-box-body -->

</div><!-- /.login-box -->

    <?php echo $__env->make('la.layouts.partials.scripts_auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <script>
        $(function () {
            $('input').iCheck({
                checkboxClass: 'icheckbox_square-blue',
                radioClass: 'iradio_square-blue',
                increaseArea: '20%' // optional
            });
        });
    </script>
</body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('la.layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>